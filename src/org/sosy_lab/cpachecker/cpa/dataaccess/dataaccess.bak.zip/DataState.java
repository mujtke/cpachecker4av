package org.sosy_lab.cpachecker.cpa.dataaccess;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataState {
    /**
     * 数据访问集中存放的类型及相关方法
     */
    private String N;
    private State A;
    private Map<String,List<String>> interOperation;
    private List<State> interState;


    public DataState(String Name) {
        /* 初始化 DataAccess[var]=[] */
        N = Name;
        A = new State();
        this.interOperation = new HashMap<String,List<String>>();
        this.interState = new ArrayList<State>();
    }

    public DataState(String Name, State a) {
        N = Name;
        A = a;
        this.interOperation = new HashMap<String,List<String>>();
        this.interState = new ArrayList<State>();
    }

    public DataState(String Name, State a, String flag) {
        if (flag == "isr") {
            N = Name;
            A = new State();
            this.interOperation = new HashMap<String,List<String>>();
            this.interState = new ArrayList<State>();
            interState.add(a);
        }
    }

    public DataState(String n, State a, Map<String,List<String>> interOperation, List<State> interState) {
        N = n;
        A = a;
        this.interOperation = new HashMap<>(interOperation);
        this.interState = new ArrayList<>(interState);
    }

    public String getN() {
        return N;
    }

    public void setN(String n) {
        N = n;
    }

    public State getA() {
        return A;
    }

    public void setA(State a) {
        A = a;
    }


    public Map<String,List<String>> getInterOperation() {
        return interOperation;
    }

    public void setInterOperation(State a) {
        if( !interOperation.containsKey(a.getTask()) ){
            List<String> action = new ArrayList<String>();
            action.add(a.getAction());
            interOperation.put(a.getName(),action);
        } else if(!interOperation.get(a.getTask()).contains(a.getAction())){
            this.interOperation.get(a.getName()).add(a.getAction());
        }


    }

    public List<State> getInterState() {
        return interState;
    }

    public void setInterState(State a) {
        this.interState.add(a);
    }


    public void updataActionList(State a) {
        if (a.getTask().contains("isr")) {
            this.setInterOperation(a);
            this.setInterState(a);
        } else{
            A = a;
        }
    }

    public void getEmpty() {
        A = new State();
        interState = new ArrayList<State>();
        interOperation = new HashMap<String ,List<String>>();
    }

    @Override
    public String toString() {
        StringBuffer str = new StringBuffer();
        str.append("\n对于 " + N + " 来说:" +
                "\n                 在非中断函数的最新访问状态是" + A +
                "\n                 在中断函数的访问状态集是" + interState);
        return String.valueOf(str);
    }

}
