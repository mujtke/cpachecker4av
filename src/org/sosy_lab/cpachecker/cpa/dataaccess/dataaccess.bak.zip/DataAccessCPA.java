package org.sosy_lab.cpachecker.cpa.dataaccess;

import de.uni_freiburg.informatik.ultimate.smtinterpol.Config;
import org.sosy_lab.common.configuration.InvalidConfigurationException;
import org.sosy_lab.cpachecker.cfa.model.CFANode;
import org.sosy_lab.cpachecker.core.defaults.AbstractCPA;
import org.sosy_lab.cpachecker.core.defaults.AutomaticCPAFactory;
import org.sosy_lab.cpachecker.core.defaults.MergeSepOperator;
import org.sosy_lab.cpachecker.core.defaults.StopNeverOperator;
import org.sosy_lab.cpachecker.core.interfaces.*;
import org.sosy_lab.cpachecker.cpa.cintp.CIntpCPAStatistics;
import org.sosy_lab.cpachecker.cpa.cintp.CIntpStatistics;

import javax.security.auth.login.AppConfigurationEntry;

import org.sosy_lab.common.configuration.Configuration;

import java.util.Collection;


public class DataAccessCPA implements ConfigurableProgramAnalysis, StatisticsProvider{

    public static RaceNum raceNum;
    private DataAccessStatistics stats;
    private Configuration config;
    private TransferRelation transferRelation;

    public static CPAFactory factory() {
        return AutomaticCPAFactory.forType(DataAccessCPA.class);
    }

    public DataAccessCPA(Configuration pConfig) throws InvalidConfigurationException {
        raceNum = new RaceNum();
        config = pConfig;
        stats = new DataAccessStatistics();
        transferRelation = new DataAccessTransferRelation(config, stats);
    }

    @Override
    public AbstractDomain getAbstractDomain() {
        return null;
    }

    @Override
    public TransferRelation getTransferRelation() {
        return transferRelation;
    }

    @Override
    public MergeOperator getMergeOperator() {
        return MergeSepOperator.getInstance();
    }

    @Override
    public StopOperator getStopOperator() {
        return new StopNeverOperator();
    }

    @Override
    public AbstractState getInitialState(CFANode node, StateSpacePartition partition) throws InterruptedException {
        return DataAccessState.getInitialInstance();
    }

    @Override
    public void collectStatistics(Collection<Statistics> statsCollection) {
        statsCollection.add(stats);
    }
}
